function telephoneCheck(str) {
    const validNumber = [
        /^\d{3}-\d{3}-\d{4}$/,
        /^\d{3} \d{3} \d{4}$/,
        /^1? ?\d{3}-\d{3}-\d{4}$/,
        /^1? ?\(\d{3}\) ?\d{3}-\d{4}$/,
        /^\(\d{3}\) ?\d{3}-\d{4}$/,
        /^1? ?\d{3} ?\d{3} ?\d{4}$/
    ]
	return validNumber.some((pattern) => pattern.test(str))
}

// telephoneCheck('555-555-5555')
